from .models import MyfUser, Field, Culture, DatesCults

from django.contrib import admin


admin.site.register(MyfUser)
admin.site.register(Field)
admin.site.register(Culture)
admin.site.register(DatesCults)
